<script setup>
import Modal from '@/Components/Modal.vue';
    import InputError from '@/Components/InputError.vue';
    import InputLabel from '@/Components/InputLabel.vue';
    import PrimaryButton from '@/Components/PrimaryButton.vue';
    import SecondaryButton from '@/Components/SecondaryButton.vue';
    import TextInput from '@/Components/TextInput.vue';
    import SelectInput from '@/Components/SelectInput.vue';
    import DatetimeInput from '@/Components/DatetimeInput.vue';
    import Checkbox from '@/Components/Checkbox.vue';

import { useForm } from '@inertiajs/vue3';
import { watchEffect, reactive } from 'vue';

const props = defineProps({
    show: Boolean,
    title: String,
    Reporte: Object,
    valoresSelect: Object,
    showUsers: Object,
})

const data = reactive({
    multipleSelect: false,
})

const emit = defineEmits(["close"]);

const form = useForm({
    fecha_ini: '',
    fecha_fin: '',
    horas_trabajadas: '',
    centro_costo_id: '',
    observaciones: '',
});

const update = () => {
    form.put(route('Reportes.update', props.Reporte?.id), {
        preserveScroll: true,
        onSuccess: () => {
            emit("close")
            form.reset()
            data.multipleSelect = false
        },
        onError: () => null,
        onFinish: () => null,
    })
}

watchEffect(() => {
    if (props.show) {
        form.errors = {}
        form.fecha_ini = props.Reporte?.fecha_ini
        form.fecha_fin = props.Reporte?.fecha_fin
        form.horas_trabajadas = props.Reporte?.horas_trabajadas
        form.centro_costo_id = props.Reporte?.centro_costo_id
        form.observaciones = props.Reporte?.observaciones
    }
})
</script>

<template>
    <section class="space-y-6">
        <Modal :show="props.show" @close="emit('close')">
            <form class="p-6" @submit.prevent="update">
                <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                    {{ lang().label.edit }} {{ props.title }} <b>{{ props.showUsers[props.Reporte.user_id] }}</b>
                </h2>
                <div class="my-6 grid grid-cols-2 gap-6">

                    <div>
                        <InputLabel for="fecha_ini" :value="lang().label.fecha_ini" />
                        <input type="datetime-local" id="fecha_ini" 
                            v-model="form.fecha_ini" required
                            name="fecha_fin" class="mt-1 block w-full" />
                    </div>
                    <div>
                        <InputLabel for="fecha_fin" :value="lang().label.fecha_fin" />
                        <input type="datetime-local" id="fecha_fin" 
                            v-model="form.fecha_fin" required
                            name="fecha_fin" class="mt-1 block w-full">
                    </div>
                    <div>
                        <InputLabel for="horas_trabajadas" :value="lang().label.horas_trabajadas" />
                        <TextInput id="horas_trabajadas" type="number" class="mt-1 block w-full" v-model="form.horas_trabajadas" disabled
                            :placeholder="lang().placeholder.horas_trabajadas" :error="form.errors.horas_trabajadas" />
                        <InputError class="mt-2" :message="form.errors.horas_trabajadas" />
                    </div>
                    <div>
                        <InputLabel for="centro_costo_id" :value="lang().label.centro_costo_id" />
                        <SelectInput v-model="form.centro_costo_id" :dataSet="props.valoresSelect" class="mt-1 block w-full" />
                        <InputError class="mt-2" :message="form.errors.centro_costo_id" />
                    </div>
                </div>
                <div class="my-6 ">
                    <InputLabel for="observaciones" :value="lang().label.observaciones + ' (Porque se esta rechazando)'" />
                        <textarea
                            id="observaciones" type="text" v-model="form.observaciones"
                            class="mt-1 block w-full rounded-md shadow-sm dark:bg-black dark:text-white placeholder:text-gray-400 placeholder:dark:text-gray-400/50"
                            cols="30" rows="3" :error="form.errors.observaciones">
                        </textarea>
                    <InputError class="mt-2" :message="form.errors.observaciones" />
                </div>
                <div class="flex justify-end">
                    <SecondaryButton :disabled="form.processing" @click="emit('close')"> {{ lang().button.close }}
                    </SecondaryButton>
                    <PrimaryButton class="ml-3" :class="{ 'opacity-25': form.processing }" :disabled="form.processing"
                        @click="update">
                        {{ form.processing ? lang().button.reject + '...' : lang().button.reject }}
                    </PrimaryButton>
                </div>
            </form>

        </Modal>
    </section>
</template>
