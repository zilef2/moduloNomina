@extends('default')

@section('content')

	{{ $post->id }}

@stop