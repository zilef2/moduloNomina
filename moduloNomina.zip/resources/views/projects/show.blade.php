@extends('default')

@section('content')

	{{ $project->id }}

@stop