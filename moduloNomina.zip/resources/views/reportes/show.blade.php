@extends('default')

@section('content')

	{{ $reporte->id }}

@stop