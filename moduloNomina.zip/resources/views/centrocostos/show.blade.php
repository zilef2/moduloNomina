@extends('default')

@section('content')

	{{ $centrocosto->id }}

@stop