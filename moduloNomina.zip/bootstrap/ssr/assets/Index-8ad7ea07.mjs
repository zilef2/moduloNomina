import { mergeProps, useSSRContext, reactive, watchEffect, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, watch, resolveDirective, openBlock, createBlock, createCommentVNode, vShow, Fragment, renderList, vModelCheckbox } from "vue";
import { ssrRenderAttrs, ssrRenderSlot, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrGetDirectiveProps, ssrRenderList, ssrIncludeBooleanAttr, ssrLooseContain } from "vue/server-renderer";
import { _ as _sfc_main$d, a as _sfc_main$e } from "./Breadcrumb-3777929b.mjs";
import { useForm, usePage, router, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$6, a as _sfc_main$7, b as _sfc_main$8 } from "./TextInput-a307f8df.mjs";
import { _ as _sfc_main$b } from "./PrimaryButton-2c41e289.mjs";
import { _ as _sfc_main$9 } from "./SelectInput-d8b73601.mjs";
import { _ as _sfc_main$c } from "./DangerButton-12e2709d.mjs";
import pkg from "lodash";
import { _ as _sfc_main$g, a as _sfc_main$h } from "./InfoButton-9b8de26f.mjs";
import { TrashIcon, ChevronUpDownIcon, PencilIcon, CheckIcon, XCircleIcon } from "@heroicons/vue/24/solid";
import { _ as _sfc_main$f } from "./Checkbox-d02a6e0f.mjs";
import { _ as _sfc_main$5, a as _sfc_main$a } from "./SecondaryButton-ee4ce9eb.mjs";
import "./SwitchLangNavbar-29a11f20.mjs";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main$4 = {
  __name: "SuccessButton",
  __ssrInlineRender: true,
  props: {
    type: {
      type: String,
      default: "submit"
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<button${ssrRenderAttrs(mergeProps({
        type: __props.type,
        class: "inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-500 active:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition ease-in-out duration-150"
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</button>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/SuccessButton.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "Create",
  __ssrInlineRender: true,
  props: {
    show: Boolean,
    title: String,
    valoresSelect: Object,
    IntegerDefectoSelect: Number
  },
  emits: ["close"],
  setup(__props, { emit }) {
    const props = __props;
    const data = reactive({
      multipleSelect: false
    });
    const form = useForm({
      // fecha_ini: '2018-06-07T01:00',
      fecha_ini: "",
      fecha_fin: "",
      horas_trabajadas: "",
      centro_costo_id: props.IntegerDefectoSelect,
      observaciones: ""
    });
    const create = () => {
      form.post(route("Reportes.store"), {
        preserveScroll: true,
        onSuccess: () => {
          emit("close");
          form.reset();
          data.multipleSelect = false;
        },
        onError: () => {
        },
        onFinish: () => null
      });
    };
    watchEffect(() => {
      if (props.show) {
        form.errors = {};
      }
      if (Date.parse(form.fecha_ini) > Date.parse(form.fecha_fin)) {
        form.horas = 0;
      } else {
        form.horas_trabajadas = parseInt((Date.parse(form.fecha_fin) - Date.parse(form.fecha_ini)) / (3600 * 1e3));
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$5, {
        show: props.show,
        onClose: ($event) => emit("close")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(_ctx.lang().label.add)} ${ssrInterpolate(props.title)}</h2><div class="my-6 grid grid-cols-2 gap-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              for: "fecha_ini",
              value: _ctx.lang().label.fecha_ini
            }, null, _parent2, _scopeId));
            _push2(`<input type="datetime-local" id="fecha_ini"${ssrRenderAttr("value", unref(form).fecha_ini)} required name="fecha_fin" class="mt-1 block w-full"${_scopeId}></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              for: "fecha_fin",
              value: _ctx.lang().label.fecha_fin
            }, null, _parent2, _scopeId));
            _push2(`<input type="datetime-local" id="fecha_fin"${ssrRenderAttr("value", unref(form).fecha_fin)} required name="fecha_fin" class="mt-1 block w-full"${_scopeId}></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              for: "horas_trabajadas",
              value: _ctx.lang().label.horas_trabajadas
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$7, {
              id: "horas_trabajadas",
              type: "number",
              class: "mt-1 block w-full",
              modelValue: unref(form).horas_trabajadas,
              "onUpdate:modelValue": ($event) => unref(form).horas_trabajadas = $event,
              disabled: "",
              placeholder: _ctx.lang().placeholder.horas_trabajadas,
              error: unref(form).errors.horas_trabajadas
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$8, {
              class: "mt-2",
              message: unref(form).errors.horas_trabajadas
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              for: "centro_costo_id",
              value: _ctx.lang().label.centro_costo_id
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$9, {
              modelValue: unref(form).centro_costo_id,
              "onUpdate:modelValue": ($event) => unref(form).centro_costo_id = $event,
              dataSet: props.valoresSelect,
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$8, {
              class: "mt-2",
              message: unref(form).errors.centro_costo_id
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$a, {
              disabled: unref(form).processing,
              onClick: ($event) => emit("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().button.close)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$b, {
              class: ["ml-3", { "opacity-25": unref(form).processing }],
              disabled: unref(form).processing,
              onClick: create
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? _ctx.lang().button.add + "..." : _ctx.lang().button.add)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.add + "..." : _ctx.lang().button.add), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "p-6",
                onSubmit: withModifiers(create, ["prevent"])
              }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(_ctx.lang().label.add) + " " + toDisplayString(props.title), 1),
                createVNode("div", { class: "my-6 grid grid-cols-2 gap-6" }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$6, {
                      for: "fecha_ini",
                      value: _ctx.lang().label.fecha_ini
                    }, null, 8, ["value"]),
                    withDirectives(createVNode("input", {
                      type: "datetime-local",
                      id: "fecha_ini",
                      "onUpdate:modelValue": ($event) => unref(form).fecha_ini = $event,
                      required: "",
                      name: "fecha_fin",
                      class: "mt-1 block w-full"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).fecha_ini]
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$6, {
                      for: "fecha_fin",
                      value: _ctx.lang().label.fecha_fin
                    }, null, 8, ["value"]),
                    withDirectives(createVNode("input", {
                      type: "datetime-local",
                      id: "fecha_fin",
                      "onUpdate:modelValue": ($event) => unref(form).fecha_fin = $event,
                      required: "",
                      name: "fecha_fin",
                      class: "mt-1 block w-full"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).fecha_fin]
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$6, {
                      for: "horas_trabajadas",
                      value: _ctx.lang().label.horas_trabajadas
                    }, null, 8, ["value"]),
                    createVNode(_sfc_main$7, {
                      id: "horas_trabajadas",
                      type: "number",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).horas_trabajadas,
                      "onUpdate:modelValue": ($event) => unref(form).horas_trabajadas = $event,
                      disabled: "",
                      placeholder: _ctx.lang().placeholder.horas_trabajadas,
                      error: unref(form).errors.horas_trabajadas
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "error"]),
                    createVNode(_sfc_main$8, {
                      class: "mt-2",
                      message: unref(form).errors.horas_trabajadas
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$6, {
                      for: "centro_costo_id",
                      value: _ctx.lang().label.centro_costo_id
                    }, null, 8, ["value"]),
                    createVNode(_sfc_main$9, {
                      modelValue: unref(form).centro_costo_id,
                      "onUpdate:modelValue": ($event) => unref(form).centro_costo_id = $event,
                      dataSet: props.valoresSelect,
                      class: "mt-1 block w-full"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet"]),
                    createVNode(_sfc_main$8, {
                      class: "mt-2",
                      message: unref(form).errors.centro_costo_id
                    }, null, 8, ["message"])
                  ])
                ]),
                createVNode("div", { class: "flex justify-end" }, [
                  createVNode(_sfc_main$a, {
                    disabled: unref(form).processing,
                    onClick: ($event) => emit("close")
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled", "onClick"]),
                  createVNode(_sfc_main$b, {
                    class: ["ml-3", { "opacity-25": unref(form).processing }],
                    disabled: unref(form).processing,
                    onClick: create
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.add + "..." : _ctx.lang().button.add), 1)
                    ]),
                    _: 1
                  }, 8, ["class", "disabled"])
                ])
              ], 40, ["onSubmit"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/reportes/Create.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    show: Boolean,
    title: String,
    Reporte: Object,
    valoresSelect: Object,
    showUsers: Object
  },
  emits: ["close"],
  setup(__props, { emit }) {
    const props = __props;
    const data = reactive({
      multipleSelect: false
    });
    const form = useForm({
      fecha_ini: "",
      fecha_fin: "",
      horas_trabajadas: "",
      centro_costo_id: "",
      observaciones: ""
    });
    const update = () => {
      var _a;
      form.put(route("Reportes.update", (_a = props.Reporte) == null ? void 0 : _a.id), {
        preserveScroll: true,
        onSuccess: () => {
          emit("close");
          form.reset();
          data.multipleSelect = false;
        },
        onError: () => null,
        onFinish: () => null
      });
    };
    watchEffect(() => {
      var _a, _b, _c, _d, _e;
      if (props.show) {
        form.errors = {};
        form.fecha_ini = (_a = props.Reporte) == null ? void 0 : _a.fecha_ini;
        form.fecha_fin = (_b = props.Reporte) == null ? void 0 : _b.fecha_fin;
        form.horas_trabajadas = (_c = props.Reporte) == null ? void 0 : _c.horas_trabajadas;
        form.centro_costo_id = (_d = props.Reporte) == null ? void 0 : _d.centro_costo_id;
        form.observaciones = (_e = props.Reporte) == null ? void 0 : _e.observaciones;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$5, {
        show: props.show,
        onClose: ($event) => emit("close")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(_ctx.lang().label.edit)} ${ssrInterpolate(props.title)} <b${_scopeId}>${ssrInterpolate(props.showUsers[props.Reporte.user_id])}</b></h2><div class="my-6 grid grid-cols-2 gap-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              for: "fecha_ini",
              value: _ctx.lang().label.fecha_ini
            }, null, _parent2, _scopeId));
            _push2(`<input type="datetime-local" id="fecha_ini"${ssrRenderAttr("value", unref(form).fecha_ini)} required name="fecha_fin" class="mt-1 block w-full"${_scopeId}></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              for: "fecha_fin",
              value: _ctx.lang().label.fecha_fin
            }, null, _parent2, _scopeId));
            _push2(`<input type="datetime-local" id="fecha_fin"${ssrRenderAttr("value", unref(form).fecha_fin)} required name="fecha_fin" class="mt-1 block w-full"${_scopeId}></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              for: "horas_trabajadas",
              value: _ctx.lang().label.horas_trabajadas
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$7, {
              id: "horas_trabajadas",
              type: "number",
              class: "mt-1 block w-full",
              modelValue: unref(form).horas_trabajadas,
              "onUpdate:modelValue": ($event) => unref(form).horas_trabajadas = $event,
              disabled: "",
              placeholder: _ctx.lang().placeholder.horas_trabajadas,
              error: unref(form).errors.horas_trabajadas
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$8, {
              class: "mt-2",
              message: unref(form).errors.horas_trabajadas
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              for: "centro_costo_id",
              value: _ctx.lang().label.centro_costo_id
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$9, {
              modelValue: unref(form).centro_costo_id,
              "onUpdate:modelValue": ($event) => unref(form).centro_costo_id = $event,
              dataSet: props.valoresSelect,
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$8, {
              class: "mt-2",
              message: unref(form).errors.centro_costo_id
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="my-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              for: "observaciones",
              value: _ctx.lang().label.observaciones + " (Porque se esta rechazando)"
            }, null, _parent2, _scopeId));
            _push2(`<textarea id="observaciones" type="text" class="mt-1 block w-full rounded-md shadow-sm dark:bg-black dark:text-white placeholder:text-gray-400 placeholder:dark:text-gray-400/50" cols="30" rows="3"${ssrRenderAttr("error", unref(form).errors.observaciones)}${_scopeId}>${ssrInterpolate(unref(form).observaciones)}</textarea>`);
            _push2(ssrRenderComponent(_sfc_main$8, {
              class: "mt-2",
              message: unref(form).errors.observaciones
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$a, {
              disabled: unref(form).processing,
              onClick: ($event) => emit("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().button.close)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$b, {
              class: ["ml-3", { "opacity-25": unref(form).processing }],
              disabled: unref(form).processing,
              onClick: update
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? _ctx.lang().button.reject + "..." : _ctx.lang().button.reject)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.reject + "..." : _ctx.lang().button.reject), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "p-6",
                onSubmit: withModifiers(update, ["prevent"])
              }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, [
                  createTextVNode(toDisplayString(_ctx.lang().label.edit) + " " + toDisplayString(props.title) + " ", 1),
                  createVNode("b", null, toDisplayString(props.showUsers[props.Reporte.user_id]), 1)
                ]),
                createVNode("div", { class: "my-6 grid grid-cols-2 gap-6" }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$6, {
                      for: "fecha_ini",
                      value: _ctx.lang().label.fecha_ini
                    }, null, 8, ["value"]),
                    withDirectives(createVNode("input", {
                      type: "datetime-local",
                      id: "fecha_ini",
                      "onUpdate:modelValue": ($event) => unref(form).fecha_ini = $event,
                      required: "",
                      name: "fecha_fin",
                      class: "mt-1 block w-full"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).fecha_ini]
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$6, {
                      for: "fecha_fin",
                      value: _ctx.lang().label.fecha_fin
                    }, null, 8, ["value"]),
                    withDirectives(createVNode("input", {
                      type: "datetime-local",
                      id: "fecha_fin",
                      "onUpdate:modelValue": ($event) => unref(form).fecha_fin = $event,
                      required: "",
                      name: "fecha_fin",
                      class: "mt-1 block w-full"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).fecha_fin]
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$6, {
                      for: "horas_trabajadas",
                      value: _ctx.lang().label.horas_trabajadas
                    }, null, 8, ["value"]),
                    createVNode(_sfc_main$7, {
                      id: "horas_trabajadas",
                      type: "number",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).horas_trabajadas,
                      "onUpdate:modelValue": ($event) => unref(form).horas_trabajadas = $event,
                      disabled: "",
                      placeholder: _ctx.lang().placeholder.horas_trabajadas,
                      error: unref(form).errors.horas_trabajadas
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "error"]),
                    createVNode(_sfc_main$8, {
                      class: "mt-2",
                      message: unref(form).errors.horas_trabajadas
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$6, {
                      for: "centro_costo_id",
                      value: _ctx.lang().label.centro_costo_id
                    }, null, 8, ["value"]),
                    createVNode(_sfc_main$9, {
                      modelValue: unref(form).centro_costo_id,
                      "onUpdate:modelValue": ($event) => unref(form).centro_costo_id = $event,
                      dataSet: props.valoresSelect,
                      class: "mt-1 block w-full"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet"]),
                    createVNode(_sfc_main$8, {
                      class: "mt-2",
                      message: unref(form).errors.centro_costo_id
                    }, null, 8, ["message"])
                  ])
                ]),
                createVNode("div", { class: "my-6" }, [
                  createVNode(_sfc_main$6, {
                    for: "observaciones",
                    value: _ctx.lang().label.observaciones + " (Porque se esta rechazando)"
                  }, null, 8, ["value"]),
                  withDirectives(createVNode("textarea", {
                    id: "observaciones",
                    type: "text",
                    "onUpdate:modelValue": ($event) => unref(form).observaciones = $event,
                    class: "mt-1 block w-full rounded-md shadow-sm dark:bg-black dark:text-white placeholder:text-gray-400 placeholder:dark:text-gray-400/50",
                    cols: "30",
                    rows: "3",
                    error: unref(form).errors.observaciones
                  }, "\r\n                        ", 8, ["onUpdate:modelValue", "error"]), [
                    [vModelText, unref(form).observaciones]
                  ]),
                  createVNode(_sfc_main$8, {
                    class: "mt-2",
                    message: unref(form).errors.observaciones
                  }, null, 8, ["message"])
                ]),
                createVNode("div", { class: "flex justify-end" }, [
                  createVNode(_sfc_main$a, {
                    disabled: unref(form).processing,
                    onClick: ($event) => emit("close")
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled", "onClick"]),
                  createVNode(_sfc_main$b, {
                    class: ["ml-3", { "opacity-25": unref(form).processing }],
                    disabled: unref(form).processing,
                    onClick: update
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.reject + "..." : _ctx.lang().button.reject), 1)
                    ]),
                    _: 1
                  }, 8, ["class", "disabled"])
                ])
              ], 40, ["onSubmit"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/reportes/Edit.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "Delete",
  __ssrInlineRender: true,
  props: {
    show: Boolean,
    title: String,
    Reporte: Object
  },
  emits: ["close"],
  setup(__props, { emit }) {
    const props = __props;
    const form = useForm({});
    const destory = () => {
      var _a;
      form.delete(route("Reportes.destroy", (_a = props.Reporte) == null ? void 0 : _a.id), {
        preserveScroll: true,
        onSuccess: () => {
          emit("close");
          form.reset();
        },
        onError: () => {
          alert(JSON.stringify(form.errors, null, 4));
        },
        onFinish: () => null
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$5, {
        show: props.show,
        onClose: ($event) => emit("close"),
        maxWidth: "lg"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(_ctx.lang().label.delete)} ${ssrInterpolate(props.title)}</h2><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"${_scopeId}>${ssrInterpolate(_ctx.lang().label.delete_confirm)} !? </p><div class="mt-6 flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$a, {
              disabled: unref(form).processing,
              onClick: ($event) => emit("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().button.close)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$c, {
              class: ["ml-3", { "opacity-25": unref(form).processing }],
              disabled: unref(form).processing,
              onClick: destory
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? _ctx.lang().button.delete + "..." : _ctx.lang().button.delete)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.delete + "..." : _ctx.lang().button.delete), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "p-6",
                onSubmit: withModifiers(destory, ["prevent"])
              }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(_ctx.lang().label.delete) + " " + toDisplayString(props.title), 1),
                createVNode("p", { class: "mt-1 text-sm text-gray-600 dark:text-gray-400" }, toDisplayString(_ctx.lang().label.delete_confirm) + " !? ", 1),
                createVNode("div", { class: "mt-6 flex justify-end" }, [
                  createVNode(_sfc_main$a, {
                    disabled: unref(form).processing,
                    onClick: ($event) => emit("close")
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled", "onClick"]),
                  createVNode(_sfc_main$c, {
                    class: ["ml-3", { "opacity-25": unref(form).processing }],
                    disabled: unref(form).processing,
                    onClick: destory
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.delete + "..." : _ctx.lang().button.delete), 1)
                    ]),
                    _: 1
                  }, 8, ["class", "disabled"])
                ])
              ], 40, ["onSubmit"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/reportes/Delete.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    title: String,
    filters: Object,
    fromController: Object,
    breadcrumbs: Object,
    perPage: Number,
    nombresTabla: Array,
    valoresSelect: Object,
    showSelect: Object,
    showUsers: Object,
    IntegerDefectoSelect: Number
  },
  setup(__props) {
    const props = __props;
    const { _, debounce, pickBy } = pkg;
    const data = reactive({
      params: {
        search: props.filters.search,
        field: props.filters.field,
        order: props.filters.order,
        perPage: props.perPage
      },
      selectedId: [],
      multipleSelect: false,
      createOpen: false,
      editOpen: false,
      deleteOpen: false,
      deleteBulkOpen: false,
      generico: null,
      nope: null,
      dataSet: usePage().props.app.perpage
    });
    const order = (field) => {
      if (field != void 0 && field != null) {
        field = field.substr(2);
        data.params.field = field.replace(/ /g, "_");
        data.params.order = data.params.order === "asc" ? "desc" : "asc";
      }
    };
    watch(() => _.cloneDeep(data.params), debounce(() => {
      let params = pickBy(data.params);
      router.get(route("Reportes.index"), params, {
        replace: true,
        preserveState: true,
        preserveScroll: true
      });
    }, 150));
    const selectAll = (event) => {
      var _a;
      if (event.target.checked === false) {
        data.selectedId = [];
      } else {
        (_a = props.fromController) == null ? void 0 : _a.data.forEach((generico) => {
          data.selectedId.push(generico.id);
        });
      }
    };
    const select = () => {
      var _a;
      if (((_a = props.fromController) == null ? void 0 : _a.data.length) == data.selectedId.length) {
        data.multipleSelect = true;
      } else {
        data.multipleSelect = false;
      }
    };
    function formatDate(date, isDateTime) {
      const validDate = new Date(date);
      const day = validDate.getDate().toString().padStart(2, "0");
      const month = monthName((validDate.getMonth() + 1).toString().padStart(2, "0"));
      let year = validDate.getFullYear();
      let anioActual = new Date().getFullYear();
      if ("conLaHora") {
        let hora = validDate.getHours();
        const AMPM = hora >= 12 ? " PM" : " AM";
        hora = hora % 12 || 12;
        let hourAndtime = hora + ":" + (validDate.getMinutes() === 0 ? "00" : validDate.getMinutes()) + AMPM;
        if (anioActual == year) {
          return `${day}-${month} | ${hourAndtime}`;
        } else {
          year = year.toString().slice(-2);
          return `${day}-${month}-${year} | ${hourAndtime}`;
        }
      } else {
        if (anioActual == year) {
          return `${day}-${month}`;
        } else {
          year = year.toString().slice(-2);
          return `${day}-${month}-${year}`;
        }
      }
    }
    function number_format(amount, decimals, isPesos) {
      amount += "";
      amount = parseFloat(amount.replace(/[^0-9\.]/g, ""));
      decimals = decimals || 0;
      if (isNaN(amount) || amount === 0)
        return parseFloat(0).toFixed(decimals);
      amount = "" + amount.toFixed(decimals);
      var amount_parts = amount.split(" "), regexp = /(\d+)(\d{3})/;
      while (regexp.test(amount_parts[0]))
        amount_parts[0] = amount_parts[0].replace(regexp, "$1.$2");
      if (isPesos)
        return "$" + amount_parts.join(" ");
      return amount_parts.join(" ");
    }
    function monthName(monthNumber) {
      if (monthNumber == 1)
        return "Enero";
      if (monthNumber == 2)
        return "Febrero";
      if (monthNumber == 3)
        return "Marzo";
      if (monthNumber == 4)
        return "Abril";
      if (monthNumber == 5)
        return "Mayo";
      if (monthNumber == 6)
        return "Junio";
      if (monthNumber == 7)
        return "Julio";
      if (monthNumber == 8)
        return "Agosto";
      if (monthNumber == 9)
        return "Septiembre";
      if (monthNumber == 10)
        return "Octubre";
      if (monthNumber == 11)
        return "Noviembre";
      if (monthNumber == 12)
        return "Diciembre";
    }
    const form = useForm({
      valido: false
    });
    const updateThisReporte = (esValido) => {
      var _a;
      form.valido = esValido;
      form.put(route("Reportes.update", (_a = data.generico) == null ? void 0 : _a.id), {
        preserveScroll: true,
        onSuccess: () => {
          form.reset();
        },
        onError: () => null,
        onFinish: () => null
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_tooltip = resolveDirective("tooltip");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: props.title
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$d, null, {
        default: withCtx((_2, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$e, {
              title: __props.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
            _push2(`<div class="space-y-4"${_scopeId}><div class="px-4 sm:px-0"${_scopeId}><div class="rounded-lg overflow-hidden w-fit"${_scopeId}>`);
            if (_ctx.can(["create reporte"])) {
              _push2(ssrRenderComponent(_sfc_main$b, {
                class: "rounded-none",
                onClick: ($event) => data.createOpen = true
              }, {
                default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(_ctx.lang().button.add)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.lang().button.add), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(_sfc_main$3, {
              show: data.createOpen,
              onClose: ($event) => data.createOpen = false,
              title: props.title,
              valoresSelect: props.valoresSelect,
              IntegerDefectoSelect: props.IntegerDefectoSelect
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: data.editOpen,
              onClose: ($event) => data.editOpen = false,
              Reporte: data.generico,
              title: props.title,
              valoresSelect: props.valoresSelect,
              showUsers: props.showUsers
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$1, {
              show: data.deleteOpen,
              onClose: ($event) => data.deleteOpen = false,
              Reporte: data.generico,
              title: props.title
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="relative bg-white dark:bg-gray-800 shadow sm:rounded-lg"${_scopeId}><div class="flex justify-between p-2"${_scopeId}><div class="flex space-x-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$9, {
              modelValue: data.params.perPage,
              "onUpdate:modelValue": ($event) => data.params.perPage = $event,
              dataSet: data.dataSet
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$c, mergeProps({
              onClick: ($event) => data.deleteBulkOpen = true,
              style: data.selectedId.length != 0 ? null : { display: "none" },
              class: "px-3 py-1.5"
            }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.delete_selected)), {
              default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TrashIcon), { class: "w-5 h-5" }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(TrashIcon), { class: "w-5 h-5" })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_sfc_main$7, {
              style: _ctx.can(["update reporte"]) ? null : { display: "none" },
              modelValue: data.params.search,
              "onUpdate:modelValue": ($event) => data.params.search = $event,
              type: "text",
              class: "block w-3/6 md:w-2/6 lg:w-1/6 rounded-lg",
              placeholder: _ctx.lang().placeholder.search
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="overflow-x-auto scrollbar-table"${_scopeId}><table class="w-full"${_scopeId}><thead class="uppercase text-sm border-t border-gray-200 dark:border-gray-700"${_scopeId}><tr class="dark:bg-gray-900 text-left"${_scopeId}><th class="px-2 py-4 text-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$f, {
              checked: data.multipleSelect,
              "onUpdate:checked": ($event) => data.multipleSelect = $event,
              onChange: selectAll
            }, null, _parent2, _scopeId));
            _push2(`</th><!--[-->`);
            ssrRenderList(__props.nombresTabla[0], (titulos, indiceN) => {
              _push2(`<th class="px-2 py-4 cursor-pointer hover:bg-sky-50 dark:hover:bg-sky-800"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>${ssrInterpolate(titulos)}</span>`);
              if (__props.nombresTabla[2][indiceN] != null) {
                _push2(ssrRenderComponent(unref(ChevronUpDownIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></th>`);
            });
            _push2(`<!--]--></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.fromController.data, (clasegenerica, index) => {
              _push2(`<tr class="border-t border-gray-200 dark:border-gray-700 hover:bg-gray-200/30 hover:dark:bg-gray-900/20"${_scopeId}><td class="whitespace-nowrap py-4 px-2 sm:py-3 text-center"${_scopeId}><input type="checkbox"${ssrRenderAttr("value", clasegenerica.id)}${ssrIncludeBooleanAttr(Array.isArray(data.selectedId) ? ssrLooseContain(data.selectedId, clasegenerica.id) : data.selectedId) ? " checked" : ""} class="rounded dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-primary dark:text-primary shadow-sm focus:ring-primary/80 dark:focus:ring-primary dark:focus:ring-offset-gray-800 dark:checked:bg-primary dark:checked:border-primary"${_scopeId}></td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><div class="flex justify-start items-center"${_scopeId}><div class="flex rounded-md overflow-hidden"${_scopeId}>`);
              if (_ctx.can(["update reporte"])) {
                _push2(ssrRenderComponent(_sfc_main$g, mergeProps({
                  type: "button",
                  onClick: ($event) => (data.editOpen = true, data.generico = clasegenerica),
                  class: "px-2 py-1.5 rounded-none"
                }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.edit)), {
                  default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(PencilIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`<form${_scopeId}>`);
              if (_ctx.can(["update reporte"])) {
                _push2(ssrRenderComponent(_sfc_main$4, {
                  type: "button",
                  class: ["ml-3", { "opacity-25": unref(form).processing }],
                  disabled: unref(form).processing,
                  onClick: ($event) => (data.generico = clasegenerica, updateThisReporte(true))
                }, {
                  default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(CheckIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(CheckIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</form>`);
              if (_ctx.can(["delete reporte"])) {
                _push2(ssrRenderComponent(_sfc_main$c, mergeProps({
                  type: "button",
                  onClick: ($event) => (data.deleteOpen = true, data.generico = clasegenerica),
                  class: "px-2 py-1.5 rounded-none"
                }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.delete)), {
                  default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div></td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(index + 1)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(__props.showSelect[clasegenerica.centro_costo_id])}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(__props.showUsers[clasegenerica.user_id])}</td><!--[-->`);
              ssrRenderList(__props.nombresTabla[1], (titulo_slug, indi) => {
                _push2(`<td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>`);
                if (titulo_slug.substr(0, 1) == "s") {
                  _push2(`<div${_scopeId}>${ssrInterpolate(clasegenerica[titulo_slug.substr(2)])}</div>`);
                } else if (titulo_slug.substr(0, 1) == "d") {
                  _push2(`<div${_scopeId}>${ssrInterpolate(formatDate(clasegenerica[titulo_slug.substr(2)]))}</div>`);
                } else if (titulo_slug.substr(0, 1) == "t") {
                  _push2(`<div${_scopeId}>${ssrInterpolate(formatDate(clasegenerica[titulo_slug.substr(2)]))}</div>`);
                } else if (titulo_slug.substr(0, 1) == "b") {
                  _push2(`<div${_scopeId}>`);
                  if (clasegenerica[titulo_slug.substr(2)] === 0) {
                    _push2(`<div${_scopeId}> Aun no validada</div>`);
                  } else if (clasegenerica[titulo_slug.substr(2)] === 1) {
                    _push2(`<div${_scopeId}>`);
                    _push2(ssrRenderComponent(unref(CheckIcon), { class: "w-8 h-8 text-green-600" }, null, _parent2, _scopeId));
                    _push2(`</div>`);
                  } else if (clasegenerica[titulo_slug.substr(2)] === 2) {
                    _push2(`<div${_scopeId}>`);
                    _push2(ssrRenderComponent(unref(XCircleIcon), { class: "w-8 h-8 text-red-600" }, null, _parent2, _scopeId));
                    _push2(`</div>`);
                  } else {
                    _push2(`<!---->`);
                  }
                  _push2(`</div>`);
                } else if (titulo_slug.substr(0, 1) == "i") {
                  _push2(`<div${_scopeId}>${ssrInterpolate(number_format(clasegenerica[titulo_slug.substr(2)]))}</div>`);
                } else if (titulo_slug.substr(0, 1) == "m") {
                  _push2(`<div${_scopeId}>${ssrInterpolate(number_format(clasegenerica[titulo_slug.substr(2)], 0, 1))}</div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</td>`);
              });
              _push2(`<!--]--></tr>`);
            });
            _push2(`<!--]--></tbody></table></div><div class="flex justify-betwween items-center p-2 border-t border-gray-200 dark:border-gray-700"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$h, {
              links: props.fromController,
              filters: data.params
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode(_sfc_main$e, {
                title: __props.title,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"]),
              createVNode("div", { class: "space-y-4" }, [
                createVNode("div", { class: "px-4 sm:px-0" }, [
                  createVNode("div", { class: "rounded-lg overflow-hidden w-fit" }, [
                    _ctx.can(["create reporte"]) ? (openBlock(), createBlock(_sfc_main$b, {
                      key: 0,
                      class: "rounded-none",
                      onClick: ($event) => data.createOpen = true
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(_ctx.lang().button.add), 1)
                      ]),
                      _: 1
                    }, 8, ["onClick"])) : createCommentVNode("", true),
                    createVNode(_sfc_main$3, {
                      show: data.createOpen,
                      onClose: ($event) => data.createOpen = false,
                      title: props.title,
                      valoresSelect: props.valoresSelect,
                      IntegerDefectoSelect: props.IntegerDefectoSelect
                    }, null, 8, ["show", "onClose", "title", "valoresSelect", "IntegerDefectoSelect"]),
                    createVNode(_sfc_main$2, {
                      show: data.editOpen,
                      onClose: ($event) => data.editOpen = false,
                      Reporte: data.generico,
                      title: props.title,
                      valoresSelect: props.valoresSelect,
                      showUsers: props.showUsers
                    }, null, 8, ["show", "onClose", "Reporte", "title", "valoresSelect", "showUsers"]),
                    createVNode(_sfc_main$1, {
                      show: data.deleteOpen,
                      onClose: ($event) => data.deleteOpen = false,
                      Reporte: data.generico,
                      title: props.title
                    }, null, 8, ["show", "onClose", "Reporte", "title"])
                  ])
                ]),
                createVNode("div", { class: "relative bg-white dark:bg-gray-800 shadow sm:rounded-lg" }, [
                  createVNode("div", { class: "flex justify-between p-2" }, [
                    createVNode("div", { class: "flex space-x-2" }, [
                      createVNode(_sfc_main$9, {
                        modelValue: data.params.perPage,
                        "onUpdate:modelValue": ($event) => data.params.perPage = $event,
                        dataSet: data.dataSet
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet"]),
                      withDirectives((openBlock(), createBlock(_sfc_main$c, {
                        onClick: ($event) => data.deleteBulkOpen = true,
                        class: "px-3 py-1.5"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(TrashIcon), { class: "w-5 h-5" })
                        ]),
                        _: 1
                      }, 8, ["onClick"])), [
                        [vShow, data.selectedId.length != 0],
                        [_directive_tooltip, _ctx.lang().tooltip.delete_selected]
                      ])
                    ]),
                    withDirectives(createVNode(_sfc_main$7, {
                      modelValue: data.params.search,
                      "onUpdate:modelValue": ($event) => data.params.search = $event,
                      type: "text",
                      class: "block w-3/6 md:w-2/6 lg:w-1/6 rounded-lg",
                      placeholder: _ctx.lang().placeholder.search
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder"]), [
                      [vShow, _ctx.can(["update reporte"])]
                    ])
                  ]),
                  createVNode("div", { class: "overflow-x-auto scrollbar-table" }, [
                    createVNode("table", { class: "w-full" }, [
                      createVNode("thead", { class: "uppercase text-sm border-t border-gray-200 dark:border-gray-700" }, [
                        createVNode("tr", { class: "dark:bg-gray-900 text-left" }, [
                          createVNode("th", { class: "px-2 py-4 text-center" }, [
                            createVNode(_sfc_main$f, {
                              checked: data.multipleSelect,
                              "onUpdate:checked": ($event) => data.multipleSelect = $event,
                              onChange: selectAll
                            }, null, 8, ["checked", "onUpdate:checked"])
                          ]),
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.nombresTabla[0], (titulos, indiceN) => {
                            return openBlock(), createBlock("th", {
                              key: indiceN,
                              onClick: ($event) => order(__props.nombresTabla[2][indiceN]),
                              class: "px-2 py-4 cursor-pointer hover:bg-sky-50 dark:hover:bg-sky-800"
                            }, [
                              createVNode("div", { class: "flex justify-between items-center" }, [
                                createVNode("span", null, toDisplayString(titulos), 1),
                                __props.nombresTabla[2][indiceN] != null ? (openBlock(), createBlock(unref(ChevronUpDownIcon), {
                                  key: 0,
                                  class: "w-4 h-4"
                                })) : createCommentVNode("", true)
                              ])
                            ], 8, ["onClick"]);
                          }), 128))
                        ])
                      ]),
                      createVNode("tbody", null, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.fromController.data, (clasegenerica, index) => {
                          return openBlock(), createBlock("tr", {
                            key: index,
                            class: "border-t border-gray-200 dark:border-gray-700 hover:bg-gray-200/30 hover:dark:bg-gray-900/20"
                          }, [
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3 text-center" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                onChange: select,
                                value: clasegenerica.id,
                                "onUpdate:modelValue": ($event) => data.selectedId = $event,
                                class: "rounded dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-primary dark:text-primary shadow-sm focus:ring-primary/80 dark:focus:ring-primary dark:focus:ring-offset-gray-800 dark:checked:bg-primary dark:checked:border-primary"
                              }, null, 40, ["value", "onUpdate:modelValue"]), [
                                [vModelCheckbox, data.selectedId]
                              ])
                            ]),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              createVNode("div", { class: "flex justify-start items-center" }, [
                                createVNode("div", { class: "flex rounded-md overflow-hidden" }, [
                                  _ctx.can(["update reporte"]) ? withDirectives((openBlock(), createBlock(_sfc_main$g, {
                                    key: 0,
                                    type: "button",
                                    onClick: ($event) => (data.editOpen = true, data.generico = clasegenerica),
                                    class: "px-2 py-1.5 rounded-none"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])), [
                                    [_directive_tooltip, _ctx.lang().tooltip.edit]
                                  ]) : createCommentVNode("", true),
                                  createVNode("form", {
                                    onSubmit: withModifiers(updateThisReporte, ["prevent"])
                                  }, [
                                    _ctx.can(["update reporte"]) ? (openBlock(), createBlock(_sfc_main$4, {
                                      key: 0,
                                      type: "button",
                                      class: ["ml-3", { "opacity-25": unref(form).processing }],
                                      disabled: unref(form).processing,
                                      onClick: ($event) => (data.generico = clasegenerica, updateThisReporte(true))
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(unref(CheckIcon), { class: "w-4 h-4" })
                                      ]),
                                      _: 2
                                    }, 1032, ["class", "disabled", "onClick"])) : createCommentVNode("", true)
                                  ], 40, ["onSubmit"]),
                                  _ctx.can(["delete reporte"]) ? withDirectives((openBlock(), createBlock(_sfc_main$c, {
                                    key: 1,
                                    type: "button",
                                    onClick: ($event) => (data.deleteOpen = true, data.generico = clasegenerica),
                                    class: "px-2 py-1.5 rounded-none"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])), [
                                    [_directive_tooltip, _ctx.lang().tooltip.delete]
                                  ]) : createCommentVNode("", true)
                                ])
                              ])
                            ]),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(index + 1), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(__props.showSelect[clasegenerica.centro_costo_id]), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(__props.showUsers[clasegenerica.user_id]), 1),
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.nombresTabla[1], (titulo_slug, indi) => {
                              return openBlock(), createBlock("td", {
                                key: indi,
                                class: "whitespace-nowrap py-4 px-2 sm:py-3"
                              }, [
                                titulo_slug.substr(0, 1) == "s" ? (openBlock(), createBlock("div", { key: 0 }, toDisplayString(clasegenerica[titulo_slug.substr(2)]), 1)) : titulo_slug.substr(0, 1) == "d" ? (openBlock(), createBlock("div", { key: 1 }, toDisplayString(formatDate(clasegenerica[titulo_slug.substr(2)])), 1)) : titulo_slug.substr(0, 1) == "t" ? (openBlock(), createBlock("div", { key: 2 }, toDisplayString(formatDate(clasegenerica[titulo_slug.substr(2)])), 1)) : titulo_slug.substr(0, 1) == "b" ? (openBlock(), createBlock("div", { key: 3 }, [
                                  clasegenerica[titulo_slug.substr(2)] === 0 ? (openBlock(), createBlock("div", { key: 0 }, " Aun no validada")) : clasegenerica[titulo_slug.substr(2)] === 1 ? (openBlock(), createBlock("div", { key: 1 }, [
                                    createVNode(unref(CheckIcon), { class: "w-8 h-8 text-green-600" })
                                  ])) : clasegenerica[titulo_slug.substr(2)] === 2 ? (openBlock(), createBlock("div", { key: 2 }, [
                                    createVNode(unref(XCircleIcon), { class: "w-8 h-8 text-red-600" })
                                  ])) : createCommentVNode("", true)
                                ])) : titulo_slug.substr(0, 1) == "i" ? (openBlock(), createBlock("div", { key: 4 }, toDisplayString(number_format(clasegenerica[titulo_slug.substr(2)])), 1)) : titulo_slug.substr(0, 1) == "m" ? (openBlock(), createBlock("div", { key: 5 }, toDisplayString(number_format(clasegenerica[titulo_slug.substr(2)], 0, 1)), 1)) : createCommentVNode("", true)
                              ]);
                            }), 128))
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "flex justify-betwween items-center p-2 border-t border-gray-200 dark:border-gray-700" }, [
                    createVNode(_sfc_main$h, {
                      links: props.fromController,
                      filters: data.params
                    }, null, 8, ["links", "filters"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Reportes/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
