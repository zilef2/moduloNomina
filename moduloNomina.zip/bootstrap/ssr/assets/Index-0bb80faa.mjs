import { reactive, watchEffect, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, useSSRContext, openBlock, createBlock, Fragment, renderList, watch, resolveDirective, withDirectives, vShow, createCommentVNode } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrGetDirectiveProps } from "vue/server-renderer";
import { _ as _sfc_main$b, a as _sfc_main$c } from "./Breadcrumb-3777929b.mjs";
import { useForm, usePage, router, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$5, a as _sfc_main$6, b as _sfc_main$7 } from "./TextInput-a307f8df.mjs";
import { _ as _sfc_main$9 } from "./PrimaryButton-2c41e289.mjs";
import { _ as _sfc_main$d } from "./SelectInput-d8b73601.mjs";
import { _ as _sfc_main$a } from "./DangerButton-12e2709d.mjs";
import pkg from "lodash";
import { _ as _sfc_main$e, a as _sfc_main$f } from "./InfoButton-9b8de26f.mjs";
import { TrashIcon, ChevronUpDownIcon, PencilIcon } from "@heroicons/vue/24/solid";
import { _ as _sfc_main$4, a as _sfc_main$8 } from "./SecondaryButton-ee4ce9eb.mjs";
import "./Checkbox-d02a6e0f.mjs";
import "./SwitchLangNavbar-29a11f20.mjs";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main$3 = {
  __name: "Create",
  __ssrInlineRender: true,
  props: {
    show: Boolean,
    title: String
  },
  emits: ["close"],
  setup(__props, { emit }) {
    const props = __props;
    const data = reactive({
      multipleSelect: false
    });
    const form = useForm({
      nombre: ""
    });
    const create = () => {
      form.post(route("CentroCostos.store"), {
        preserveScroll: true,
        onSuccess: () => {
          emit("close");
          form.reset();
          data.multipleSelect = false;
        },
        onError: () => alert(errors.create),
        onFinish: () => null
      });
    };
    watchEffect(() => {
      if (props.show) {
        form.errors = {};
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$4, {
        show: props.show,
        onClose: ($event) => emit("close")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(_ctx.lang().label.add)} ${ssrInterpolate(props.title)}</h2><div class="my-6 grid grid-cols-1 gap-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$5, {
              for: "nombre",
              value: _ctx.lang().label.name
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              id: "nombre",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(form).nombre,
              "onUpdate:modelValue": ($event) => unref(form).nombre = $event,
              required: "",
              placeholder: _ctx.lang().placeholder.nombre,
              error: unref(form).errors.nombre
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$7, {
              class: "mt-2",
              message: unref(form).errors.nombre
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$8, {
              disabled: unref(form).processing,
              onClick: ($event) => emit("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().button.close)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$9, {
              class: ["ml-3", { "opacity-25": unref(form).processing }],
              disabled: unref(form).processing,
              onClick: create
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? _ctx.lang().button.add + "..." : _ctx.lang().button.add)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.add + "..." : _ctx.lang().button.add), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "p-6",
                onSubmit: withModifiers(create, ["prevent"])
              }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(_ctx.lang().label.add) + " " + toDisplayString(props.title), 1),
                createVNode("div", { class: "my-6 grid grid-cols-1 gap-6" }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$5, {
                      for: "nombre",
                      value: _ctx.lang().label.name
                    }, null, 8, ["value"]),
                    createVNode(_sfc_main$6, {
                      id: "nombre",
                      type: "text",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).nombre,
                      "onUpdate:modelValue": ($event) => unref(form).nombre = $event,
                      required: "",
                      placeholder: _ctx.lang().placeholder.nombre,
                      error: unref(form).errors.nombre
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "error"]),
                    createVNode(_sfc_main$7, {
                      class: "mt-2",
                      message: unref(form).errors.nombre
                    }, null, 8, ["message"])
                  ])
                ]),
                createVNode("div", { class: "flex justify-end" }, [
                  createVNode(_sfc_main$8, {
                    disabled: unref(form).processing,
                    onClick: ($event) => emit("close")
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled", "onClick"]),
                  createVNode(_sfc_main$9, {
                    class: ["ml-3", { "opacity-25": unref(form).processing }],
                    disabled: unref(form).processing,
                    onClick: create
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.add + "..." : _ctx.lang().button.add), 1)
                    ]),
                    _: 1
                  }, 8, ["class", "disabled"])
                ])
              ], 40, ["onSubmit"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/centroCostos/Create.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    show: Boolean,
    title: String,
    CentroCosto: Object
  },
  emits: ["close"],
  setup(__props, { emit }) {
    const props = __props;
    const data = reactive({
      multipleSelect: false
    });
    const form = useForm({
      nombre: ""
    });
    const printForm = [
      { idd: "nombre", label: "nombre", type: "text", value: form.nombre }
    ];
    const update = () => {
      var _a;
      form.put(route("CentroCostos.update", (_a = props.CentroCosto) == null ? void 0 : _a.id), {
        preserveScroll: true,
        onSuccess: () => {
          emit("close");
          form.reset();
          data.multipleSelect = false;
        },
        onError: () => null,
        onFinish: () => null
      });
    };
    watchEffect(() => {
      var _a;
      if (props.show) {
        form.errors = {};
        form.nombre = (_a = props.CentroCosto) == null ? void 0 : _a.nombre;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$4, {
        show: props.show,
        onClose: ($event) => emit("close")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(_ctx.lang().label.edit)} ${ssrInterpolate(props.title)}</h2><div class="my-6 grid grid-cols-2 gap-6"${_scopeId}><!--[-->`);
            ssrRenderList(printForm, (atributosform, indice) => {
              _push2(`<div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$5, {
                for: atributosform.label,
                value: atributosform.value
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$6, {
                id: atributosform.idd,
                type: atributosform.type,
                class: "mt-1 block w-full",
                modelValue: unref(form)[atributosform.idd],
                "onUpdate:modelValue": ($event) => unref(form)[atributosform.idd] = $event,
                required: "",
                placeholder: atributosform.label,
                error: unref(form).errors[atributosform.idd]
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            });
            _push2(`<!--]--></div><div class="flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$8, {
              disabled: unref(form).processing,
              onClick: ($event) => emit("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().button.close)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$9, {
              class: ["ml-3", { "opacity-25": unref(form).processing }],
              disabled: unref(form).processing,
              onClick: update
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? _ctx.lang().button.save + "..." : _ctx.lang().button.save)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.save + "..." : _ctx.lang().button.save), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "p-6",
                onSubmit: withModifiers(update, ["prevent"])
              }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(_ctx.lang().label.edit) + " " + toDisplayString(props.title), 1),
                createVNode("div", { class: "my-6 grid grid-cols-2 gap-6" }, [
                  (openBlock(), createBlock(Fragment, null, renderList(printForm, (atributosform, indice) => {
                    return createVNode("div", { key: indice }, [
                      createVNode(_sfc_main$5, {
                        for: atributosform.label,
                        value: atributosform.value
                      }, null, 8, ["for", "value"]),
                      createVNode(_sfc_main$6, {
                        id: atributosform.idd,
                        type: atributosform.type,
                        class: "mt-1 block w-full",
                        modelValue: unref(form)[atributosform.idd],
                        "onUpdate:modelValue": ($event) => unref(form)[atributosform.idd] = $event,
                        required: "",
                        placeholder: atributosform.label,
                        error: unref(form).errors[atributosform.idd]
                      }, null, 8, ["id", "type", "modelValue", "onUpdate:modelValue", "placeholder", "error"])
                    ]);
                  }), 64))
                ]),
                createVNode("div", { class: "flex justify-end" }, [
                  createVNode(_sfc_main$8, {
                    disabled: unref(form).processing,
                    onClick: ($event) => emit("close")
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled", "onClick"]),
                  createVNode(_sfc_main$9, {
                    class: ["ml-3", { "opacity-25": unref(form).processing }],
                    disabled: unref(form).processing,
                    onClick: update
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.save + "..." : _ctx.lang().button.save), 1)
                    ]),
                    _: 1
                  }, 8, ["class", "disabled"])
                ])
              ], 40, ["onSubmit"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/centroCostos/Edit.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "Delete",
  __ssrInlineRender: true,
  props: {
    show: Boolean,
    title: String,
    CentroCosto: Object
  },
  emits: ["close"],
  setup(__props, { emit }) {
    const props = __props;
    const form = useForm({});
    const destory = () => {
      var _a;
      form.delete(route("CentroCostos.destroy", (_a = props.CentroCosto) == null ? void 0 : _a.id), {
        preserveScroll: true,
        onSuccess: () => {
          emit("close");
          form.reset();
        },
        onError: () => null,
        onFinish: () => null
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$4, {
        show: props.show,
        onClose: ($event) => emit("close"),
        maxWidth: "lg"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<form class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(_ctx.lang().label.delete)} ${ssrInterpolate(props.title)}</h2><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"${_scopeId}>${ssrInterpolate(_ctx.lang().label.delete_confirm)} <b${_scopeId}>${ssrInterpolate((_a = props.CentroCosto) == null ? void 0 : _a.nombre)} !?</b></p><div class="mt-6 flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$8, {
              disabled: unref(form).processing,
              onClick: ($event) => emit("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().button.close)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$a, {
              class: ["ml-3", { "opacity-25": unref(form).processing }],
              disabled: unref(form).processing,
              onClick: destory
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? _ctx.lang().button.delete + "..." : _ctx.lang().button.delete)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.delete + "..." : _ctx.lang().button.delete), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "p-6",
                onSubmit: withModifiers(destory, ["prevent"])
              }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(_ctx.lang().label.delete) + " " + toDisplayString(props.title), 1),
                createVNode("p", { class: "mt-1 text-sm text-gray-600 dark:text-gray-400" }, [
                  createTextVNode(toDisplayString(_ctx.lang().label.delete_confirm) + " ", 1),
                  createVNode("b", null, toDisplayString((_b = props.CentroCosto) == null ? void 0 : _b.nombre) + " !?", 1)
                ]),
                createVNode("div", { class: "mt-6 flex justify-end" }, [
                  createVNode(_sfc_main$8, {
                    disabled: unref(form).processing,
                    onClick: ($event) => emit("close")
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled", "onClick"]),
                  createVNode(_sfc_main$a, {
                    class: ["ml-3", { "opacity-25": unref(form).processing }],
                    disabled: unref(form).processing,
                    onClick: destory
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.delete + "..." : _ctx.lang().button.delete), 1)
                    ]),
                    _: 1
                  }, 8, ["class", "disabled"])
                ])
              ], 40, ["onSubmit"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/centroCostos/Delete.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    title: String,
    filters: Object,
    fromController: Object,
    breadcrumbs: Object,
    perPage: Number,
    nombresTabla: Array
  },
  setup(__props) {
    const props = __props;
    const { _, debounce, pickBy } = pkg;
    const data = reactive({
      params: {
        search: props.filters.search,
        field: props.filters.field,
        order: props.filters.order,
        perPage: props.perPage
      },
      selectedId: [],
      multipleSelect: false,
      createOpen: false,
      editOpen: false,
      deleteOpen: false,
      deleteBulkOpen: false,
      generico: null,
      dataSet: usePage().props.app.perpage
    });
    const order = (field) => {
      if (field != void 0) {
        data.params.field = field.replace(/ /g, "_");
        data.params.order = data.params.order === "asc" ? "desc" : "asc";
      }
    };
    watch(() => _.cloneDeep(data.params), debounce(() => {
      let params = pickBy(data.params);
      router.get(route("CentroCostos.index"), params, {
        replace: true,
        preserveState: true,
        preserveScroll: true
      });
    }, 150));
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_tooltip = resolveDirective("tooltip");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: props.title
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$b, null, {
        default: withCtx((_2, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$c, {
              title: __props.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
            _push2(`<div class="space-y-4"${_scopeId}><div class="px-4 sm:px-0"${_scopeId}><div class="rounded-lg overflow-hidden w-fit"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$9, {
              class: "rounded-none",
              onClick: ($event) => data.createOpen = true
            }, {
              default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().button.add)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().button.add), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              show: data.createOpen,
              onClose: ($event) => data.createOpen = false,
              title: props.title
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: data.editOpen,
              onClose: ($event) => data.editOpen = false,
              CentroCosto: data.generico,
              title: props.title
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$1, {
              show: data.deleteOpen,
              onClose: ($event) => data.deleteOpen = false,
              CentroCosto: data.generico,
              title: props.title
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="relative bg-white dark:bg-gray-800 shadow sm:rounded-lg"${_scopeId}><div class="flex justify-between p-2"${_scopeId}><div class="flex space-x-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$d, {
              modelValue: data.params.perPage,
              "onUpdate:modelValue": ($event) => data.params.perPage = $event,
              dataSet: data.dataSet
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$a, mergeProps({
              onClick: ($event) => data.deleteBulkOpen = true,
              style: data.selectedId.length != 0 ? null : { display: "none" },
              class: "px-3 py-1.5"
            }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.delete_selected)), {
              default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TrashIcon), { class: "w-5 h-5" }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(TrashIcon), { class: "w-5 h-5" })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              modelValue: data.params.search,
              "onUpdate:modelValue": ($event) => data.params.search = $event,
              type: "text",
              class: "block w-3/6 md:w-2/6 lg:w-1/6 rounded-lg",
              placeholder: _ctx.lang().placeholder.search
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="overflow-x-auto scrollbar-table"${_scopeId}><table class="w-full"${_scopeId}><thead class="uppercase text-sm border-t border-gray-200 dark:border-gray-700"${_scopeId}><tr class="dark:bg-gray-900 text-left"${_scopeId}><!--[-->`);
            ssrRenderList(__props.nombresTabla[0], (titulos, indiceN) => {
              _push2(`<th class="px-2 py-4 cursor-pointer hover:bg-sky-50 dark:hover:bg-sky-800"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>${ssrInterpolate(titulos)}</span>`);
              if (__props.nombresTabla[1][indiceN]) {
                _push2(ssrRenderComponent(unref(ChevronUpDownIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></th>`);
            });
            _push2(`<!--]--></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.fromController.data, (clasegenerica, index) => {
              _push2(`<tr class="border-t border-gray-200 dark:border-gray-700 hover:bg-gray-200/30 hover:dark:bg-gray-900/20"${_scopeId}><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(index + 1)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(clasegenerica.nombre)}</td>`);
              if (_ctx.can(["update centroCostos"])) {
                _push2(`<td class="whitespace-nowrap py-4 px-2 sm:py-3 text-center"${_scopeId}><div class="flex justify-start items-center"${_scopeId}><div class="rounded-md overflow-hidden"${_scopeId}>`);
                _push2(ssrRenderComponent(_sfc_main$e, mergeProps({
                  type: "button",
                  onClick: ($event) => (data.editOpen = true, data.generico = clasegenerica),
                  class: "px-2 py-1.5 rounded-none"
                }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.edit)), {
                  default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(PencilIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(_sfc_main$a, mergeProps({
                  type: "button",
                  onClick: ($event) => (data.deleteOpen = true, data.generico = clasegenerica),
                  class: "px-2 py-1.5 rounded-none"
                }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.delete)), {
                  default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div></div></td>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</tr>`);
            });
            _push2(`<!--]--></tbody></table></div><div class="flex justify-betwween items-center p-2 border-t border-gray-200 dark:border-gray-700"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$f, {
              links: props.fromController,
              filters: data.params
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode(_sfc_main$c, {
                title: __props.title,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"]),
              createVNode("div", { class: "space-y-4" }, [
                createVNode("div", { class: "px-4 sm:px-0" }, [
                  createVNode("div", { class: "rounded-lg overflow-hidden w-fit" }, [
                    createVNode(_sfc_main$9, {
                      class: "rounded-none",
                      onClick: ($event) => data.createOpen = true
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(_ctx.lang().button.add), 1)
                      ]),
                      _: 1
                    }, 8, ["onClick"]),
                    createVNode(_sfc_main$3, {
                      show: data.createOpen,
                      onClose: ($event) => data.createOpen = false,
                      title: props.title
                    }, null, 8, ["show", "onClose", "title"]),
                    createVNode(_sfc_main$2, {
                      show: data.editOpen,
                      onClose: ($event) => data.editOpen = false,
                      CentroCosto: data.generico,
                      title: props.title
                    }, null, 8, ["show", "onClose", "CentroCosto", "title"]),
                    createVNode(_sfc_main$1, {
                      show: data.deleteOpen,
                      onClose: ($event) => data.deleteOpen = false,
                      CentroCosto: data.generico,
                      title: props.title
                    }, null, 8, ["show", "onClose", "CentroCosto", "title"])
                  ])
                ]),
                createVNode("div", { class: "relative bg-white dark:bg-gray-800 shadow sm:rounded-lg" }, [
                  createVNode("div", { class: "flex justify-between p-2" }, [
                    createVNode("div", { class: "flex space-x-2" }, [
                      createVNode(_sfc_main$d, {
                        modelValue: data.params.perPage,
                        "onUpdate:modelValue": ($event) => data.params.perPage = $event,
                        dataSet: data.dataSet
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet"]),
                      withDirectives((openBlock(), createBlock(_sfc_main$a, {
                        onClick: ($event) => data.deleteBulkOpen = true,
                        class: "px-3 py-1.5"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(TrashIcon), { class: "w-5 h-5" })
                        ]),
                        _: 1
                      }, 8, ["onClick"])), [
                        [vShow, data.selectedId.length != 0],
                        [_directive_tooltip, _ctx.lang().tooltip.delete_selected]
                      ])
                    ]),
                    createVNode(_sfc_main$6, {
                      modelValue: data.params.search,
                      "onUpdate:modelValue": ($event) => data.params.search = $event,
                      type: "text",
                      class: "block w-3/6 md:w-2/6 lg:w-1/6 rounded-lg",
                      placeholder: _ctx.lang().placeholder.search
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder"])
                  ]),
                  createVNode("div", { class: "overflow-x-auto scrollbar-table" }, [
                    createVNode("table", { class: "w-full" }, [
                      createVNode("thead", { class: "uppercase text-sm border-t border-gray-200 dark:border-gray-700" }, [
                        createVNode("tr", { class: "dark:bg-gray-900 text-left" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.nombresTabla[0], (titulos, indiceN) => {
                            return openBlock(), createBlock("th", {
                              key: indiceN,
                              onClick: ($event) => order(__props.nombresTabla[1][indiceN]),
                              class: "px-2 py-4 cursor-pointer hover:bg-sky-50 dark:hover:bg-sky-800"
                            }, [
                              createVNode("div", { class: "flex justify-between items-center" }, [
                                createVNode("span", null, toDisplayString(titulos), 1),
                                __props.nombresTabla[1][indiceN] ? (openBlock(), createBlock(unref(ChevronUpDownIcon), {
                                  key: 0,
                                  class: "w-4 h-4"
                                })) : createCommentVNode("", true)
                              ])
                            ], 8, ["onClick"]);
                          }), 128))
                        ])
                      ]),
                      createVNode("tbody", null, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.fromController.data, (clasegenerica, index) => {
                          return openBlock(), createBlock("tr", {
                            key: index,
                            class: "border-t border-gray-200 dark:border-gray-700 hover:bg-gray-200/30 hover:dark:bg-gray-900/20"
                          }, [
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(index + 1), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(clasegenerica.nombre), 1),
                            _ctx.can(["update centroCostos"]) ? (openBlock(), createBlock("td", {
                              key: 0,
                              class: "whitespace-nowrap py-4 px-2 sm:py-3 text-center"
                            }, [
                              createVNode("div", { class: "flex justify-start items-center" }, [
                                createVNode("div", { class: "rounded-md overflow-hidden" }, [
                                  withDirectives((openBlock(), createBlock(_sfc_main$e, {
                                    type: "button",
                                    onClick: ($event) => (data.editOpen = true, data.generico = clasegenerica),
                                    class: "px-2 py-1.5 rounded-none"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])), [
                                    [_directive_tooltip, _ctx.lang().tooltip.edit]
                                  ]),
                                  withDirectives((openBlock(), createBlock(_sfc_main$a, {
                                    type: "button",
                                    onClick: ($event) => (data.deleteOpen = true, data.generico = clasegenerica),
                                    class: "px-2 py-1.5 rounded-none"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])), [
                                    [_directive_tooltip, _ctx.lang().tooltip.delete]
                                  ])
                                ])
                              ])
                            ])) : createCommentVNode("", true)
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "flex justify-betwween items-center p-2 border-t border-gray-200 dark:border-gray-700" }, [
                    createVNode(_sfc_main$f, {
                      links: props.fromController,
                      filters: data.params
                    }, null, 8, ["links", "filters"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/CentroCostos/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
