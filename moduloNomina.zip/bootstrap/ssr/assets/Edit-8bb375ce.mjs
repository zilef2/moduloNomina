import { reactive, watchEffect, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1, a as _sfc_main$6 } from "./SecondaryButton-ee4ce9eb.mjs";
import { _ as _sfc_main$2, a as _sfc_main$3, b as _sfc_main$4 } from "./TextInput-a307f8df.mjs";
import { _ as _sfc_main$7 } from "./PrimaryButton-2c41e289.mjs";
import { _ as _sfc_main$5 } from "./SelectInput-d8b73601.mjs";
import "./Checkbox-d02a6e0f.mjs";
import { useForm } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    show: Boolean,
    title: String,
    Reporte: Object,
    valoresSelect: Object,
    showUsers: Object
  },
  emits: ["close"],
  setup(__props, { emit }) {
    const props = __props;
    const data = reactive({
      multipleSelect: false
    });
    const form = useForm({
      fecha_ini: "",
      fecha_fin: "",
      horas_trabajadas: "",
      centro_costo_id: "",
      observaciones: ""
    });
    const update = () => {
      var _a;
      form.put(route("Reportes.update", (_a = props.Reporte) == null ? void 0 : _a.id), {
        preserveScroll: true,
        onSuccess: () => {
          emit("close");
          form.reset();
          data.multipleSelect = false;
        },
        onError: () => null,
        onFinish: () => null
      });
    };
    watchEffect(() => {
      var _a, _b, _c, _d, _e;
      if (props.show) {
        form.errors = {};
        form.fecha_ini = (_a = props.Reporte) == null ? void 0 : _a.fecha_ini;
        form.fecha_fin = (_b = props.Reporte) == null ? void 0 : _b.fecha_fin;
        form.horas_trabajadas = (_c = props.Reporte) == null ? void 0 : _c.horas_trabajadas;
        form.centro_costo_id = (_d = props.Reporte) == null ? void 0 : _d.centro_costo_id;
        form.observaciones = (_e = props.Reporte) == null ? void 0 : _e.observaciones;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        show: props.show,
        onClose: ($event) => emit("close")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(_ctx.lang().label.edit)} ${ssrInterpolate(props.title)} <b${_scopeId}>${ssrInterpolate(props.showUsers[props.Reporte.user_id])}</b></h2><div class="my-6 grid grid-cols-2 gap-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "fecha_ini",
              value: _ctx.lang().label.fecha_ini
            }, null, _parent2, _scopeId));
            _push2(`<input type="datetime-local" id="fecha_ini"${ssrRenderAttr("value", unref(form).fecha_ini)} required name="fecha_fin" class="mt-1 block w-full"${_scopeId}></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "fecha_fin",
              value: _ctx.lang().label.fecha_fin
            }, null, _parent2, _scopeId));
            _push2(`<input type="datetime-local" id="fecha_fin"${ssrRenderAttr("value", unref(form).fecha_fin)} required name="fecha_fin" class="mt-1 block w-full"${_scopeId}></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "horas_trabajadas",
              value: _ctx.lang().label.horas_trabajadas
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "horas_trabajadas",
              type: "number",
              class: "mt-1 block w-full",
              modelValue: unref(form).horas_trabajadas,
              "onUpdate:modelValue": ($event) => unref(form).horas_trabajadas = $event,
              disabled: "",
              placeholder: _ctx.lang().placeholder.horas_trabajadas,
              error: unref(form).errors.horas_trabajadas
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.horas_trabajadas
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "centro_costo_id",
              value: _ctx.lang().label.centro_costo_id
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              modelValue: unref(form).centro_costo_id,
              "onUpdate:modelValue": ($event) => unref(form).centro_costo_id = $event,
              dataSet: props.valoresSelect,
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.centro_costo_id
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="my-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "observaciones",
              value: _ctx.lang().label.observaciones + " (Porque se esta rechazando)"
            }, null, _parent2, _scopeId));
            _push2(`<textarea id="observaciones" type="text" class="mt-1 block w-full rounded-md shadow-sm dark:bg-black dark:text-white placeholder:text-gray-400 placeholder:dark:text-gray-400/50" cols="30" rows="3"${ssrRenderAttr("error", unref(form).errors.observaciones)}${_scopeId}>${ssrInterpolate(unref(form).observaciones)}</textarea>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.observaciones
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              disabled: unref(form).processing,
              onClick: ($event) => emit("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().button.close)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$7, {
              class: ["ml-3", { "opacity-25": unref(form).processing }],
              disabled: unref(form).processing,
              onClick: update
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? _ctx.lang().button.reject + "..." : _ctx.lang().button.reject)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.reject + "..." : _ctx.lang().button.reject), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "p-6",
                onSubmit: withModifiers(update, ["prevent"])
              }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, [
                  createTextVNode(toDisplayString(_ctx.lang().label.edit) + " " + toDisplayString(props.title) + " ", 1),
                  createVNode("b", null, toDisplayString(props.showUsers[props.Reporte.user_id]), 1)
                ]),
                createVNode("div", { class: "my-6 grid grid-cols-2 gap-6" }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "fecha_ini",
                      value: _ctx.lang().label.fecha_ini
                    }, null, 8, ["value"]),
                    withDirectives(createVNode("input", {
                      type: "datetime-local",
                      id: "fecha_ini",
                      "onUpdate:modelValue": ($event) => unref(form).fecha_ini = $event,
                      required: "",
                      name: "fecha_fin",
                      class: "mt-1 block w-full"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).fecha_ini]
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "fecha_fin",
                      value: _ctx.lang().label.fecha_fin
                    }, null, 8, ["value"]),
                    withDirectives(createVNode("input", {
                      type: "datetime-local",
                      id: "fecha_fin",
                      "onUpdate:modelValue": ($event) => unref(form).fecha_fin = $event,
                      required: "",
                      name: "fecha_fin",
                      class: "mt-1 block w-full"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).fecha_fin]
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "horas_trabajadas",
                      value: _ctx.lang().label.horas_trabajadas
                    }, null, 8, ["value"]),
                    createVNode(_sfc_main$3, {
                      id: "horas_trabajadas",
                      type: "number",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).horas_trabajadas,
                      "onUpdate:modelValue": ($event) => unref(form).horas_trabajadas = $event,
                      disabled: "",
                      placeholder: _ctx.lang().placeholder.horas_trabajadas,
                      error: unref(form).errors.horas_trabajadas
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "error"]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.horas_trabajadas
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "centro_costo_id",
                      value: _ctx.lang().label.centro_costo_id
                    }, null, 8, ["value"]),
                    createVNode(_sfc_main$5, {
                      modelValue: unref(form).centro_costo_id,
                      "onUpdate:modelValue": ($event) => unref(form).centro_costo_id = $event,
                      dataSet: props.valoresSelect,
                      class: "mt-1 block w-full"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet"]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.centro_costo_id
                    }, null, 8, ["message"])
                  ])
                ]),
                createVNode("div", { class: "my-6" }, [
                  createVNode(_sfc_main$2, {
                    for: "observaciones",
                    value: _ctx.lang().label.observaciones + " (Porque se esta rechazando)"
                  }, null, 8, ["value"]),
                  withDirectives(createVNode("textarea", {
                    id: "observaciones",
                    type: "text",
                    "onUpdate:modelValue": ($event) => unref(form).observaciones = $event,
                    class: "mt-1 block w-full rounded-md shadow-sm dark:bg-black dark:text-white placeholder:text-gray-400 placeholder:dark:text-gray-400/50",
                    cols: "30",
                    rows: "3",
                    error: unref(form).errors.observaciones
                  }, "\r\n                        ", 8, ["onUpdate:modelValue", "error"]), [
                    [vModelText, unref(form).observaciones]
                  ]),
                  createVNode(_sfc_main$4, {
                    class: "mt-2",
                    message: unref(form).errors.observaciones
                  }, null, 8, ["message"])
                ]),
                createVNode("div", { class: "flex justify-end" }, [
                  createVNode(_sfc_main$6, {
                    disabled: unref(form).processing,
                    onClick: ($event) => emit("close")
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled", "onClick"]),
                  createVNode(_sfc_main$7, {
                    class: ["ml-3", { "opacity-25": unref(form).processing }],
                    disabled: unref(form).processing,
                    onClick: update
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.reject + "..." : _ctx.lang().button.reject), 1)
                    ]),
                    _: 1
                  }, 8, ["class", "disabled"])
                ])
              ], 40, ["onSubmit"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Reportes/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
