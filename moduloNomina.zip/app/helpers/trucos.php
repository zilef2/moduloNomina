<!-- templates -->
php.json{
    aa
    var
    before
    migra
    lwv (livewire-views)
    lwc (livewire-controller)
    nunca (nunca sale)
}


# se retiro (de azasegu) del archivo resource/views/layout/app.blade
<script src="{{ mix('/js/livewire.js') }}" defer></script>


<!--  env -> enviroment -->
if (app()->environment() !== 'production') {

<!--  npm -->
<!-- You'll need to install this package globally as it manages the Node versions at the root. -->
npm install -g npm@latest
npm install -g n

Install a new version of Node
n lts
